package com.htc.javaexcercises.question3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringOperations {

	 
   
	String array[] = new String[10];
    String a = new String();
    public void linsearch(String string[], String search)
    {
        string = array;
        search = a;

        int i;
        int flag = 0;
        for(i = 0; i<10; i++)
        {
            if (search.equals(string[i]))
            {
                flag = 1;
                break;
            }

        }
        if (flag ==1)
        {
            System.out.println("Word found at position " +(i+1));
        }
        else
        {
            System.out.println("Word not found.");
        }
    }

    public static void main(String args[])throws IOException
    {
    	//str rev
    	String str= "Geeks", nstr="";
        char ch;
       
      System.out.print("Original word: ");
      System.out.println("Geeks"); //Example word
       
      for (int i=0; i<str.length(); i++)
      {
        ch= str.charAt(i); //extracts each character
        nstr= ch+nstr; //adds each character in front of the existing string
      }
      System.out.println("Reversed word: "+ nstr);
      
      //str search
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringOperations obj = new StringOperations();
        System.out.println("Enter any 10 words.");

        String enter [] = new String[10];
        int i;
        for (i = 0; i<10; i++)
        {

            enter[i] = br.readLine();

        }
        System.out.println("Enter word to be searched.");
        String search1 = br.readLine();
        obj.linsearch(enter, search1);
        
        //replace
        System.out.println(search1.replace('l', 'p'));
    }
}
