package com.htc.javaexcercises.question9;

import java.awt.*;  
import java.awt.event.*;  
import javax.swing.*;  
import java.util.*;  
import java.text.*;  
 
class NumberFormatter extends JFrame implements ActionListener  
{  
    JTextField txt1, txt2, txt3, txt4;  
    JButton btn1, btn2;  
    public NumberFormatter()  
    {  
        setLayout(new FlowLayout());  
        add(new JLabel("Language"));  
        add(txt1 = new JTextField(15));  
        add(new JLabel("Country"));  
        add(txt2 = new JTextField(15));  
        add(new JLabel("Number:"));  
        add(txt3 = new JTextField(15));  
        add(new JLabel("Formatted:"));  
        add(txt4 = new JTextField(15));  
        add(btn1 = new JButton("Number Formatting"));  
        add(btn2 = new JButton("Currency Formatting"));  
        txt4.setEditable(false);  
        setSize(630, 320);  
        setTitle("Number and Currency Formatter");  
        setVisible(true);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        btn1.addActionListener(this);  
        btn2.addActionListener(this);  
    }  
    public void actionPerformed(ActionEvent e)  
    {  
        Locale locale = new Locale(txt1.getText(), txt2.getText());  
        Object src = e.getSource();  
        NumberFormat mf;  
        if (src == btn1)  
        {  
            mf = NumberFormat.getNumberInstance(locale);  
        } else  
            mf = NumberFormat.getCurrencyInstance(locale);  
        double d = Double.parseDouble(txt3.getText());  
        txt4.setText(mf.format(d));  
    }  
    public static void main(String args[])  
    {  
        new NumberFormatter();  
    }  
}  