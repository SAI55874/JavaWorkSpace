package com.htc.javaexcercises.question7;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LocalDateInternalization {

	private static final String MAIN_DATE_FORMAT = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";
	 
	public static void main(String[] args) {
	 
	Date date = new Date();
	System.out.println("Date:" + date);
	 
	SimpleDateFormat formatter = new SimpleDateFormat(MAIN_DATE_FORMAT, Locale.CANADA);
	System.out.println("CANADA DATE :" + formatter.format(date));
	 
	formatter = new SimpleDateFormat(MAIN_DATE_FORMAT, Locale.CANADA_FRENCH);
	System.out.println("CANADA FRENCH DATE :" + formatter.format(date));
	 
	formatter = new SimpleDateFormat(MAIN_DATE_FORMAT, Locale.GERMANY);
	System.out.println("GERMANY :" + formatter.format(date));
	 
	formatter = new SimpleDateFormat(MAIN_DATE_FORMAT, Locale.CHINESE);
	System.out.println("CHINESE DATE :" + formatter.format(date));
	formatter = new SimpleDateFormat(MAIN_DATE_FORMAT, Locale.ITALIAN);
	System.out.println("ITALIAN :" + formatter.format(date));
	 
	formatter = new SimpleDateFormat(MAIN_DATE_FORMAT, Locale.TAIWAN);
	System.out.println("TAIWAN DATE :" + formatter.format(date));
	 
	    }
	 
}
