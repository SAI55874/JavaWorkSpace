package com.htc.javaexcercise.question10;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validations {

	//pwd function
	 public static boolean
	    isValidPassword(String password)
	    {
	  
	        // Regex to check valid password.
	        String regex = "^(?=.*[0-9])"
	                       + "(?=.*[a-z])(?=.*[A-Z])"
	                       + "(?=.*[@#$%^&+=])"
	                       + "(?=\\S+$).{8,20}$";
	  
	        // Compile the ReGex
	        Pattern p = Pattern.compile(regex);
	  
	        // If the password is empty
	        // return false
	        if (password == null) {
	            return false;
	        }
	  
	        // Pattern class contains matcher() method
	        // to find matching between given password
	        // and regular expression.
	        Matcher m = p.matcher(password);
	  
	        // Return if the password
	        // matched the ReGex
	        return m.matches();
	    }
	  
    public static void main(String args[]){  
    	//email validation
        ArrayList<String> emails = new ArrayList<String>();  
        emails.add("javaTpoint@domain.co.in");  
        emails.add("javaTpoint@domain.com");  
        emails.add("javaTpoint.name@domain.com");  
        emails.add("javaTpoint#@domain.co.in");  
        emails.add("javaTpoint@domain.com");  
        emails.add("javaTpoint@domaincom");  
        //Add invalid emails in list  
        emails.add("@yahoo.com");  
        emails.add("javaTpoint#domain.com");  
        //Regular Expression   
        String regex = "^(.+)@(.+)$";  
        //Compile regular expression to get the pattern  
        Pattern pattern = Pattern.compile(regex);  
        //Iterate emails array list  
        for(String email : emails){  
            //Create instance of matcher   
            Matcher matcher = pattern.matcher(email);  
            System.out.println(email +" : "+ matcher.matches()+"\n");  
        }  
        
        //pwd validation
     // Test Case 1:
        String str1 = "Geeks@portal20";
        System.out.println(isValidPassword(str1));
  
        // Test Case 2:
        String str2 = "Geeksforgeeks";
        System.out.println(isValidPassword(str2));
  
        // Test Case 3:
        String str3 = "Geeks@ portal9";
        System.out.println(isValidPassword(str3));
  
        // Test Case 4:
        String str4 = "1234";
        System.out.println(isValidPassword(str4));
  
        // Test Case 5:
        String str5 = "Gfg@20";
        System.out.println(isValidPassword(str5));
  
        // Test Case 6:
        String str6 = "geeks@portal20";
        System.out.println(isValidPassword(str6));

        //creditcard validation
        List<String> cards = new ArrayList<String>();
        
      //Valid Credit Cards
      cards.add("xxxx-xxxx-xxxx-xxxx");  //Masked to avoid any inconvenience unknowingly
       
      //Invalid Credit Card
      cards.add("xxxx-xxxx-xxxx-xxxx"); //Masked to avoid any inconvenience unknowingly
       
      String regex1 = "^(?:(?<visa>4[0-9]{12}(?:[0-9]{3})?)|" +
          "(?<mastercard>5[1-5][0-9]{14})|" +
          "(?<discover>6(?:011|5[0-9]{2})[0-9]{12})|" +
          "(?<amex>3[47][0-9]{13})|" +
          "(?<diners>3(?:0[0-5]|[68][0-9])?[0-9]{11})|" +
          "(?<jcb>(?:2131|1800|35[0-9]{3})[0-9]{11}))$";
       
      Pattern pattern1 = Pattern.compile(regex1);
       
      for (String card : cards)
      {
        //Strip all hyphens
        card = card.replaceAll("-", "");
       
        //Match the card
        Matcher matcher = pattern1.matcher(card);
       
        System.out.println(matcher.matches());
       
        if(matcher.matches()) {
          //If card is valid then verify which group it belong 
          System.out.println(matcher.group("mastercard"));
        }
        
    } 
    }
}
