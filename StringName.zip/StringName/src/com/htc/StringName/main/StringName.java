package com.htc.StringName.main;

import java.util.ArrayList;
import java.util.List;

import com.htc.StringName.pojo.EmpDetails;

public class StringName {
public static void main(String args[])
{


List<EmpDetails> Emps=new ArrayList<>();
Emps.add(new EmpDetails("Rajesh","28338","Rajesh.Shetti@htcinc.com"));
Emps.add(new EmpDetails("sai","28338","Rajesh.Shetti@htcinc.com"));
Emps.add(new EmpDetails("Chandan","28338","Rajesh.Shetti@htcinc.com"));
Emps.add(new EmpDetails("nibin","28338","Rajesh.Shetti@htcinc.com"));
Emps.add(new EmpDetails("selico","28338","Rajesh.Shetti@htcinc.com"));
Emps.add(new EmpDetails("Rajesh","28353","Ram.kumar@itcinc.com"));
Emps.add(new EmpDetails("Rajesh","28392","Rahul.h@capgemini.com"));
Emps.add(new EmpDetails("Rajesh","28872","sanjay.Shetti@yamaha.com"));
System.out.print("Company name : ");
for (EmpDetails empDetails : Emps) {
	String Str = new String(empDetails.getEmail());
	int n1=Str.indexOf("@");
	int n2=Str.indexOf(".com");
	if(Str.substring(n1+1,n2).equals("htcinc")) {
		System.out.println(empDetails.getEmpName());
	}
//	System.out.println(Str.substring(n1+1,n2));
}

}
}

