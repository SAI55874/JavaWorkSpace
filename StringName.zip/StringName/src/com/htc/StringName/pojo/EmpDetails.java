package com.htc.StringName.pojo;

import java.util.Objects;

public class EmpDetails {
	private String EmpName;
	private String EmpId;
	private String Email;
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getEmpId() {
		return EmpId;
	}
	public void setEmpId(String empId) {
		EmpId = empId;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public EmpDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmpDetails(String empName, String empId, String email) {
		super();
		EmpName = empName;
		EmpId = empId;
		Email = email;
	}
	@Override
	public int hashCode() {
		return Objects.hash(EmpId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmpDetails other = (EmpDetails) obj;
		return Objects.equals(EmpId, other.EmpId);
	}
	@Override
	public String toString() {
		return "EmpDetails [EmpName=" + EmpName + ", EmpId=" + EmpId + ", Email=" + Email + "]";
	}
}
