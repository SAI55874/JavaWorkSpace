package com.htc.Bike.main;

import com.htc.Bike.Dao.BikeDao;
import com.htc.Bike.DaoImpl.BikeDaoImpl;

public class Test1 {
public static void main(String[] args) {
	BikeDao ad=new BikeDaoImpl();
	System.out.println(ad.applyBreak("AP_39_PZ_9977"));
	System.out.println(ad.accelerate("KL_26_GH_3217", 20));
}
}
