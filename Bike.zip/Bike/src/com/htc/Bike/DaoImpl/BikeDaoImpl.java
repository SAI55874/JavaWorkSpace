package com.htc.Bike.DaoImpl;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.htc.Bike.Dao.BikeDao;
import com.htc.Bike.pojo.Bike;


public class BikeDaoImpl implements BikeDao{
	
List<Bike> bikes = new ArrayList<>();


	public BikeDaoImpl() {
	bikes.add(new Bike("AP_39_PZ_9977","FZ",110,60,4));
	bikes.add(new Bike("KL_26_GH_3217","Pulser",100,60,4));
	bikes.add(new Bike("MP_19_PZ_7467","Hero",70,40,4));
	bikes.add(new Bike("UP_22_PZ_9382","Duke",120,80,5));
	bikes.add(new Bike("TN_18_PZ_8214","TVS_Xl",40,20,0));
}


	@Override
	public Optional<Bike> applyBreak(String bike_reg_no) {
		Bike bike=null;
		for (Bike bike1 : bikes) {
		if(bike_reg_no.equals(bike1.getBike_reg_no())) {
			bike1.setCurtSpeed(0);
			bike1.setCurtGear(1);
			
			bike=bike1;
			break;
		}
		}
		return Optional.ofNullable(bike);
	}


	@Override
	public Optional<Bike> accelerate(String bike_reg_no, int Speed) {
		Bike bike=null;
		for (Bike bike1 : bikes) {
		if(bike_reg_no.equals(bike1.getBike_reg_no())) {
			
			if(Speed>0 && Speed<bike1.getMaxSpeed()) {
				bike1.setCurtSpeed(Speed);
				if(Speed>0 && Speed<=10) {
					bike1.setCurtGear(1);
				}else if(Speed>10 && Speed<=20) {
					bike1.setCurtGear(2);
				}else if(Speed>20 && Speed<=30) {
					bike1.setCurtGear(3);
				}else if(Speed>30 && Speed<=40) {
					bike1.setCurtGear(4);
				}
				bike=bike1;
				break;
			}
			else {
				break;
			}
			
			
			
			
		}
		}
		return Optional.ofNullable(bike);
	}

	

}
