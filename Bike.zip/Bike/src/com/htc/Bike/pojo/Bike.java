package com.htc.Bike.pojo;

import java.util.Objects;

public class Bike {
private String bike_reg_no;
private String bikeName;
private int maxSpeed;
private int CurtSpeed;
private int CurtGear;
public String getBike_reg_no() {
	return bike_reg_no;
}
public void setBike_reg_no(String bike_reg_no) {
	this.bike_reg_no = bike_reg_no;
}
public String getBikeName() {
	return bikeName;
}
public void setBikeName(String bikeName) {
	this.bikeName = bikeName;
}
public int getMaxSpeed() {
	return maxSpeed;
}
public void setMaxSpeed(int maxSpeed) {
	this.maxSpeed = maxSpeed;
}
public int getCurtSpeed() {
	return CurtSpeed;
}
public void setCurtSpeed(int CurtSpeed) {
	this.CurtSpeed = CurtSpeed;
}
public int getCurtGear() {
	return CurtGear;
}
public void setCurtGear(int curtGear) {
	CurtGear = curtGear;
}
public Bike() {
	super();
	// TODO Auto-generated constructor stub
}
public Bike(String bike_reg_no, String bikeName, int maxSpeed, int CurtSpeed, int curtGear) {
	super();
	this.bike_reg_no = bike_reg_no;
	this.bikeName = bikeName;
	this.maxSpeed = maxSpeed;
	this.CurtSpeed = CurtSpeed;
	this.CurtGear = curtGear;
}
@Override
public int hashCode() {
	return Objects.hash(bike_reg_no);
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Bike other = (Bike) obj;
	return Objects.equals(bike_reg_no, other.bike_reg_no);
}
@Override
public String toString() {
	return "Bike [bike_reg_no=" + bike_reg_no + ", bikeName=" + bikeName + ", maxSpeed=" + maxSpeed + ", CurtSpeed="
			+ CurtSpeed + ", CurtGear=" + CurtGear + "]";
}
}
