package com.htc.Bike.Dao;

import java.util.Optional;

import com.htc.Bike.pojo.Bike;

public interface BikeDao {
	Optional<Bike> applyBreak(String bike_reg_no);
	Optional<Bike> accelerate(String bike_reg_no,int Speed);
}
