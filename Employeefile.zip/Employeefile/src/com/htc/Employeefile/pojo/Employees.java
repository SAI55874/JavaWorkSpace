package com.htc.Employeefile.pojo;

import java.time.LocalDate;
import java.util.Objects;

public class Employees {
private String employeeId;
private String employeeName;
//private LocalDate doj;
private String doj;
private String designation;
public Employees() {
	super();
	
}
public String getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(String employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public String getDoj() {
	return doj;
}
public void setDoj(String doj) {
	this.doj = doj;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
@Override
public int hashCode() {
	return Objects.hash(employeeId);
}

public Employees(String employeeId, String employeeName, String doj, String designation) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.doj = doj;
	this.designation = designation;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Employees other = (Employees) obj;
	return Objects.equals(employeeId, other.employeeId);
}
@Override
public String toString() {
	return "Employees [employeeId=" + employeeId + ", employeeName=" + employeeName + ", doj=" + doj + ", designation="
			+ designation + "]";
}


}
