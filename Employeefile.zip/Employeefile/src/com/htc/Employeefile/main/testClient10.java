package com.htc.Employeefile.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.htc.Employeefile.pojo.Employees;

public class testClient10 {
public static void main(String[] args) {

	   try {
		      
		      InputStream fis=new FileInputStream("Employees.txt");
		      BufferedReader br=new BufferedReader(new InputStreamReader(fis));

		      for (String line = br.readLine(); line != null; line = br.readLine()) {
		    	  System.out.println(line);
		    	  String[] EmployeeDetails=line.split(",");
		    	  System.out.println(EmployeeDetails[1]);
		    	  List<Employees> emps=new ArrayList<>();
		    	  Employees emp=new Employees(EmployeeDetails[0],EmployeeDetails[1],EmployeeDetails[2],EmployeeDetails[3]);
		    	  emps.add(emp);
		    	  System.out.println(emps);
		    	  }
		      br.close();
	    	
//		      for (myReader.hasNextLine()) {
//		        String data = myReader.nextLine();
//		        String[] EmployeeDetails=data.split("\\s");
//		        System.out.println(data);
//		        System.out.println(EmployeeDetails);
//		       
//		      }
		     
		    } catch (Exception e) {
		      e.printStackTrace();
		    }
}
	
	
}
