package com.htc.Employeefile.dao;

import java.time.LocalDate;

import com.htc.Employeefile.exceptions.EmployeeNotExsists;
import com.htc.Employeefile.pojo.Employees;


public interface EmployeesDao {
		
		boolean addVehicle(Employees employees);
		boolean removeVehicle(String employeeId) throws EmployeeNotExsists;
		Employees modifyVehicle(String employeeName,LocalDate  doj,String designation) ;
		Employees getVehicle(String employeeId)	throws EmployeeNotExsists;
}
