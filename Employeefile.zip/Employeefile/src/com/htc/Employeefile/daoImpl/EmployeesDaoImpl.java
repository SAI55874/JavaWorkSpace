package com.htc.Employeefile.daoImpl;

import java.time.LocalDate;

import com.htc.Employeefile.dao.EmployeesDao;
import com.htc.Employeefile.exceptions.EmployeeNotExsists;
import com.htc.Employeefile.pojo.Employees;

public class EmployeesDaoImpl implements EmployeesDao{

	@Override
	public boolean addVehicle(Employees employees) {
		
		return false;
	}

	@Override
	public boolean removeVehicle(String employeeId) throws EmployeeNotExsists{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employees modifyVehicle(String employeeName, LocalDate doj, String designation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employees getVehicle(String employeeId)throws EmployeeNotExsists {
		// TODO Auto-generated method stub
		return null;
	}

}
